export const unemploymentData = {
    2020: {
      CA: 7.5,
      TX: 6.2,
      NY: 8.1,
      FL: 5.6,
    },
    2021: {
      CA: 6.9,
      TX: 5.5,
      NY: 7.0,
      FL: 4.8,
    },
    2022: {
      CA: 5.8,
      TX: 4.7,
      NY: 6.1,
      FL: 3.9,
    },
  };
  