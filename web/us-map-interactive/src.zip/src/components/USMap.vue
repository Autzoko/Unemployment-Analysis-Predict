<template>
  <div>
    <!-- 放置 SVG 地图 -->
    <div ref="svgContainer" class="svg-map" @mousemove="updateTooltipPosition"></div>

    <!-- Tooltip -->
    <div
      v-if="tooltip.visible"
      class="tooltip"
      :style="{ top: tooltip.y + 'px', left: tooltip.x + 'px' }"
    >
      <strong>{{ tooltip.state }}</strong><br />
      失业率：{{ tooltip.rate }}%
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, inject } from 'vue';
import { unemploymentData } from '../data/unemployment.js';
import usMapRaw from '../assets/us-map.svg?raw'; // 导入完整的 SVG 地图

const year = inject('currentYear');
const svgContainer = ref(null);

// Tooltip 数据
const tooltip = ref({
  visible: false,
  x: 0,
  y: 0,
  state: '',
  rate: '',
});

// 更新 Tooltip 位置
const updateTooltipPosition = (e) => {
  tooltip.value.x = e.pageX + 10;
  tooltip.value.y = e.pageY + 10;
};

// 显示 Tooltip 内容
const showTooltip = (code) => {
  const rate = unemploymentData[year.value]?.[code];
  tooltip.value = {
    visible: true,
    x: tooltip.value.x,
    y: tooltip.value.y,
    state: code,
    rate: rate ?? '未知',
  };
};

// 隐藏 Tooltip
const hideTooltip = () => {
  tooltip.value.visible = false;
};

onMounted(() => {
  if (svgContainer.value) {
    svgContainer.value.innerHTML = usMapRaw;

    const paths = svgContainer.value.querySelectorAll('path');
    paths.forEach(path => {
      path.classList.add('state-path');
      const code = path.id;
      path.addEventListener('mouseenter', () => showTooltip(code));
      path.addEventListener('mouseleave', hideTooltip);
    });
  }
});
</script>

<style scoped>
.svg-map {
  /* width: 100%; */
  width: 1000px;
  height: auto;
  margin: 20px auto;
  display: flex;
  justify-content: center;
}

.svg-map svg {
  width: 100%;
  height: auto;
}

.svg-map path {
  transition: transform 0.3s ease, fill 0.3s ease;
  transform-origin: center;
  cursor: pointer;
}

.svg-map path:hover {
  transform: scale(1.1);
  z-index: 10;
}

.tooltip {
  position: absolute;
  background: white;
  border: 1px solid #ddd;
  padding: 8px;
  font-size: 14px;
  border-radius: 4px;
  pointer-events: none;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}
</style>
