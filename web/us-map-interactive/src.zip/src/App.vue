<template>
  <div>
    <h2>美国失业率地图</h2>
    <label>
      选择年份：
      <select v-model="year">
        <option v-for="y in years" :key="y" :value="y">{{ y }}</option>
      </select>
    </label>
    <USMap />
  </div>
</template>

<script setup>
import { ref, provide } from 'vue';
import USMap from './components/USMap.vue';

const years = [2020, 2021, 2022];
const year = ref(2022);
provide('currentYear', year);
</script>
